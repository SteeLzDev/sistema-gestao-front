// Arquivo para exportar o hook useToast
import { useToast as useToastOriginal } from "@/components/ui/toast"

export const useToast = useToastOriginal

