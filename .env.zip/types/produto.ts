export interface Produto {
    id: number
    nome: string
    codigo: string
    categoria: string
    preco: number
    quantidade: number
  }
  
  